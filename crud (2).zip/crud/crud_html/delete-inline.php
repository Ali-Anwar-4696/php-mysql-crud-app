<?php
$stu_id = $_GET['id'];


include "Config.php";

$querry = "DELETE FROM student WHERE sid = {$stu_id}";
$result = mysqli_query($conn, $querry) or die("Unsuccessful");

header("Location: http://localhost/crud/crud_html/index.php");

mysqli_close($conn);




?>